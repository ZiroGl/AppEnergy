package br.ulbra.appenergy;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
EditText edtP,edtT,edtC;
Button btnC;
TextView txtR1,txtR2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
       edtP = findViewById(R.id.edtP);
       edtT = findViewById(R.id.edtC);
       edtC = findViewById(R.id.edtC);
       btnC = findViewById(R.id.btnC);
       txtR1 = findViewById(R.id.txtR1);
       txtR2 = findViewById(R.id.txtR2);
       btnC = findViewById(R.id.btnC);
       btnC.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               double p,c,t,r1,r2;
               try {
                   p = Double.parseDouble(edtP.getText().toString());
                   t = Double.parseDouble(edtT.getText().toString());
                   c = Double.parseDouble(edtC.getText().toString());
                   r1 = (p*t)/1000;
                   r2 = r1 * c;
                   txtR1.setText(""+r1);
                   txtR2.setText(""+r2);
               }catch (NumberFormatException e){
                   Toast.makeText(MainActivity.this, "Deu erro", Toast.LENGTH_SHORT).show();

               }
           }
       });

        };
    }
